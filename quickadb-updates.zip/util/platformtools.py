"""
platformtools.py - "adb not found" prompt and in-app download of Google's platform-tools.

The zip is downloaded next to QuickADB, extracted to <QuickADB folder>/platform-tools,
the zip is deleted, and ToolPaths is re-run so the new adb is used immediately.
"""
import os
import platform
import shutil
import ssl
import urllib.request
import zipfile
from typing import Callable, Optional

from PyQt6.QtCore import QThread, pyqtSignal, Qt
from PyQt6.QtWidgets import QMessageBox, QProgressDialog, QWidget

from util.toolpaths import ToolPaths, app_dir, default_download_dir

PLATFORM_TOOLS_URLS = {
    "Windows": "https://dl.google.com/android/repository/platform-tools-latest-windows.zip",
    "Linux": "https://dl.google.com/android/repository/platform-tools-latest-linux.zip",
    "Darwin": "https://dl.google.com/android/repository/platform-tools-latest-darwin.zip",
}
PLATFORM_TOOLS_PAGE = "https://developer.android.com/tools/releases/platform-tools"
_EXECUTABLES = ("adb", "fastboot", "mke2fs", "etc1tool", "hprof-conv", "make_f2fs",
                "make_f2fs_casefold", "sqlite3", "dmtracedump")


def platform_tools_url() -> Optional[str]:
    return PLATFORM_TOOLS_URLS.get(platform.system())


def _ssl_context() -> ssl.SSLContext:
    """Prefer certifi's CA bundle when available (frozen builds often lack system certs)."""
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


class PlatformToolsDownloader(QThread):
    """Downloads and extracts platform-tools into `dest_parent`/platform-tools."""
    progress = pyqtSignal(int, int)   # bytes done, total (0 if unknown)
    status = pyqtSignal(str)
    done = pyqtSignal(str)            # folder that now contains adb
    failed = pyqtSignal(str)

    def __init__(self, url: str, dest_parent: str):
        super().__init__()
        self.url = url
        self.dest_parent = dest_parent
        self._cancel = False

    def cancel(self):
        self._cancel = True

    def run(self):
        zip_path = os.path.join(self.dest_parent, os.path.basename(self.url) + ".part")
        try:
            os.makedirs(self.dest_parent, exist_ok=True)
            self.status.emit("Downloading platform-tools...")
            req = urllib.request.Request(self.url, headers={"User-Agent": "QuickADB"})
            with urllib.request.urlopen(req, timeout=30, context=_ssl_context()) as resp, \
                    open(zip_path, "wb") as out:
                total = int(resp.headers.get("Content-Length") or 0)
                got = 0
                while True:
                    if self._cancel:
                        raise InterruptedError("Download cancelled.")
                    chunk = resp.read(256 * 1024)
                    if not chunk:
                        break
                    out.write(chunk)
                    got += len(chunk)
                    self.progress.emit(got, total)

            self.status.emit("Extracting...")
            with zipfile.ZipFile(zip_path) as z:
                # The archive holds a single top-level platform-tools/ folder.
                for name in z.namelist():
                    if os.path.isabs(name) or ".." in name.replace("\\", "/").split("/"):
                        raise ValueError(f"Unsafe path in archive: {name}")
                target = os.path.join(self.dest_parent, "platform-tools")
                if os.path.isdir(target):
                    shutil.rmtree(target, ignore_errors=True)
                z.extractall(self.dest_parent)

            pt_dir = os.path.join(self.dest_parent, "platform-tools")
            if os.name != "nt":
                for f in _EXECUTABLES:
                    p = os.path.join(pt_dir, f)
                    if os.path.isfile(p):
                        os.chmod(p, 0o755)
            adb = os.path.join(pt_dir, "adb.exe" if os.name == "nt" else "adb")
            if not os.path.isfile(adb):
                raise FileNotFoundError("The download didn't contain adb.")
            self.done.emit(pt_dir)
        except Exception as e:
            self.failed.emit(str(e))
        finally:
            try:
                if os.path.exists(zip_path):
                    os.remove(zip_path)
            except OSError:
                pass


def start_download(parent: QWidget, on_finished: Optional[Callable[[bool], None]] = None):
    """Download platform-tools with a progress dialog. Calls on_finished(success)."""
    url = platform_tools_url()
    if not url:
        QMessageBox.warning(parent, "platform-tools",
                            f"No platform-tools download for {platform.system()}.\n"
                            f"Get it from:\n{PLATFORM_TOOLS_PAGE}")
        if on_finished:
            on_finished(False)
        return

    dest_parent = app_dir()
    dlg = QProgressDialog("Downloading platform-tools...", "Cancel", 0, 0, parent)
    dlg.setWindowTitle("platform-tools")
    dlg.setWindowModality(Qt.WindowModality.WindowModal)
    dlg.setMinimumDuration(0)
    dlg.setAutoClose(False)
    dlg.setAutoReset(False)

    worker = PlatformToolsDownloader(url, dest_parent)
    parent._pt_download_worker = worker  # keep a reference alive

    def on_progress(done, total):
        if total:
            dlg.setMaximum(total)
            dlg.setValue(done)
            dlg.setLabelText(f"Downloading platform-tools... {done / 1048576:.1f} / {total / 1048576:.1f} MB")
        else:
            dlg.setLabelText(f"Downloading platform-tools... {done / 1048576:.1f} MB")

    def finish(ok: bool, message: str = ""):
        dlg.close()
        worker.wait(2000)
        parent._pt_download_worker = None
        if ok:
            ToolPaths.instance().refresh()
            QMessageBox.information(parent, "platform-tools",
                                    f"platform-tools installed to:\n{default_download_dir()}")
        elif message != "Download cancelled.":
            QMessageBox.warning(
                parent, "platform-tools",
                f"Couldn't install platform-tools:\n{message}\n\n"
                f"You can download it manually from:\n{PLATFORM_TOOLS_PAGE}\n"
                f"and unzip it into:\n{dest_parent}")
        if on_finished:
            on_finished(ok)

    worker.progress.connect(on_progress)
    worker.status.connect(dlg.setLabelText)
    worker.done.connect(lambda _p: finish(True))
    worker.failed.connect(lambda msg: finish(False, msg))
    dlg.canceled.connect(worker.cancel)
    worker.start()
    dlg.show()


def prompt_adb_missing(parent: QWidget, on_finished: Optional[Callable[[bool], None]] = None):
    """Tell the user adb wasn't found and offer to download platform-tools."""
    resp = QMessageBox.question(
        parent,
        "adb not found",
        "adb wasn't found on your system PATH or in the QuickADB folder:\n"
        f"{app_dir()}\n\n"
        "adb comes in Google's platform-tools package. Download it now?\n"
        f"It will be saved to:\n{default_download_dir()}",
        QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        QMessageBox.StandardButton.Yes,
    )
    if resp == QMessageBox.StandardButton.Yes:
        start_download(parent, on_finished)
    elif on_finished:
        on_finished(False)
