"""
toolpaths.py  -  Single source of truth for where adb / fastboot live.

Every module should import from here instead of resolving paths locally.

Usage:
    from util.toolpaths import ToolPaths
    tp = ToolPaths.instance()
    tp.found               # True if a usable adb was located
    adb   = tp.adb         # absolute path to adb / adb.exe (bare "adb" if not found)
    fb    = tp.fastboot    # absolute path to fastboot / fastboot.exe
    ptdir = tp.platform_tools_dir  # folder containing adb
    tp.source              # "system PATH", "QuickADB folder" or "" (not found)
    tp.refresh()           # re-run detection, e.g. after downloading platform-tools

Lookup order for adb:
  1. The system PATH.
  2. The QuickADB folder and its subfolders (up to SEARCH_DEPTH levels), so
     QuickADB/platform-tools/adb.exe, QuickADB/bin/platform-tools/adb.exe,
     QuickADB/tools/adb/adb.exe etc. are all found.
  3. Nothing found: `found` is False, and the main window offers to download
     Google's platform-tools into QuickADB/platform-tools.

platform-tools is deliberately NOT bundled inside the packaged executable any more.
A one-file PyInstaller build unpacks to a temporary _MEI folder; an adb server started
from there keeps running after QuickADB exits and keeps adb.exe and its DLLs locked,
so the temporary folder can't be deleted and an error is shown on exit.
"""
import os
import shutil
import sys
from typing import List, Optional, Tuple

SEARCH_DEPTH = 4  # folder levels below the QuickADB folder to search
DOWNLOAD_DIR_NAME = "platform-tools"

# Folders never worth searching (large or irrelevant)
_SKIP_DIRS = {"__pycache__", "node_modules", "build", "dist", "venv", ".venv", "env"}


def _exe(name: str) -> str:
    return name + ".exe" if os.name == "nt" else name


def app_dir() -> str:
    """The folder the user sees QuickADB in.

    From source: the folder containing main.py.
    Packaged: the folder containing the QuickADB executable (or the AppImage file),
    never PyInstaller's temporary extraction folder.
    """
    if getattr(sys, "frozen", False):
        exe = os.environ.get("APPIMAGE") or sys.executable
        return os.path.dirname(os.path.abspath(exe))
    # this file is util/toolpaths.py, so the root is one level up
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def default_download_dir() -> str:
    """Where a downloaded platform-tools ends up: <QuickADB folder>/platform-tools."""
    return os.path.join(app_dir(), DOWNLOAD_DIR_NAME)


def _usable(path: Optional[str]) -> bool:
    return bool(path) and os.path.isfile(path) and (os.name == "nt" or os.access(path, os.X_OK))


def _from_path(tool: str) -> Optional[str]:
    found = shutil.which(tool)
    return os.path.abspath(found) if found and _usable(found) else None


def _search_folder(base: str, tool: str, depth: int = SEARCH_DEPTH) -> Optional[str]:
    """Find `tool` anywhere under `base`, up to `depth` levels down.

    Best match first: a folder named platform-tools, then the shallowest, then
    alphabetical order (so the result is stable between runs)."""
    if not os.path.isdir(base):
        return None
    target = _exe(tool).lower()
    base_depth = base.rstrip(os.sep).count(os.sep)
    found: List[Tuple[int, int, str]] = []
    for dirpath, dirnames, filenames in os.walk(base):
        level = dirpath.rstrip(os.sep).count(os.sep) - base_depth
        if level >= depth:
            dirnames[:] = []
        else:
            dirnames[:] = sorted(d for d in dirnames
                                 if not d.startswith(".") and d.lower() not in _SKIP_DIRS)
        for f in filenames:
            if f.lower() == target:
                path = os.path.join(dirpath, f)
                if _usable(path):
                    not_pt = os.path.basename(dirpath).lower() != "platform-tools"
                    found.append((not_pt, level, path))
    return sorted(found)[0][2] if found else None


class ToolPaths:
    """Singleton that resolves and caches platform-tool paths."""

    _instance = None

    def __init__(self):
        self._adb: Optional[str] = None
        self._fastboot: Optional[str] = None
        self._source: str = ""
        self.refresh()

    # --- singleton accessor ---
    @classmethod
    def instance(cls) -> "ToolPaths":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    # --- detection ---
    def refresh(self) -> bool:
        """(Re)detect adb and fastboot. Returns True if adb was found."""
        adb = _from_path("adb")
        source = "system PATH" if adb else ""
        if not adb:
            adb = _search_folder(app_dir(), "adb")
            source = "QuickADB folder" if adb else ""

        # fastboot: next to adb first (same platform-tools release), then PATH, then search
        fastboot = None
        if adb:
            beside = os.path.join(os.path.dirname(adb), _exe("fastboot"))
            fastboot = beside if _usable(beside) else None
        fastboot = fastboot or _from_path("fastboot") or _search_folder(app_dir(), "fastboot")

        self._adb, self._fastboot, self._source = adb, fastboot, source
        return adb is not None

    # --- public properties ---
    @property
    def found(self) -> bool:
        return self._adb is not None

    @property
    def fastboot_found(self) -> bool:
        return self._fastboot is not None

    @property
    def source(self) -> str:
        return self._source

    @property
    def adb(self) -> str:
        # Bare name when missing: subprocess then fails with FileNotFoundError,
        # which every caller already handles, instead of crashing on None.
        return self._adb or _exe("adb")

    @property
    def fastboot(self) -> str:
        return self._fastboot or _exe("fastboot")

    @property
    def platform_tools_dir(self) -> str:
        """Folder containing adb. Falls back to the QuickADB folder (which always exists)
        so it stays usable as a working directory when adb is missing."""
        if self._adb:
            return os.path.dirname(self._adb)
        return app_dir()
