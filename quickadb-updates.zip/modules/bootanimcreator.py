"""
bootanimcreator.py - QuickADB Boot Animation Creator. Supports extracting, creating, and pushing boot animations or creating modules.
Uses Pillow to extract frames from GIFs. For videos, user must supply FFmpeg.

"""
import os
import sys
import re
import shutil
import tempfile
import zipfile
import subprocess
import time
import shlex
from datetime import datetime
from typing import Optional, Dict, List, Tuple

from util.resource import get_root_dir, resource_path
from util.toolpaths import ToolPaths
from util.adbclient import ADBClient

root_dir = get_root_dir()
if root_dir not in sys.path:
    sys.path.insert(0, root_dir)

from util.thememanager import ThemeManager


from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QFileDialog, QMessageBox, QSpinBox, QGroupBox, QLineEdit, QTextEdit, QGridLayout,
    QDialog, QFormLayout, QDialogButtonBox, QPlainTextEdit, QSlider
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTimer, QUrl
from PyQt6.QtGui import QPixmap, QDesktopServices

from PIL import Image, ImageSequence

PLATFORM_TOOLS_DIR = ToolPaths.instance().platform_tools_dir
ADB_CMD = ToolPaths.instance().adb
def _run_adb(args: list, **kwargs):
    """Run an ADB command via ADBClient with active serial."""
    if not args:
        return None
    subcmd = args[0]
    if subcmd == "shell":
        shell_args = args[1:]
        if len(shell_args) == 1 and isinstance(shell_args[0], str):
            return ADBClient.instance().run_shell(shell_args[0], use_serial=True, **kwargs)
        return ADBClient.instance().run_shell(shell_args, use_serial=True, **kwargs)
    elif subcmd == "push":
        return ADBClient.instance().push(args[1], args[2], use_serial=True, **kwargs)
    elif subcmd == "pull":
        return ADBClient.instance().pull(args[1], args[2], use_serial=True, **kwargs)
    else:
        return ADBClient.instance().run_adb(args, use_serial=True, **kwargs)

BOOT_PATHS = [
    "/system/media/bootanimation.zip",
    "/system/product/media/bootanimation.zip",
    "/product/media/bootanimation.zip",
    "/vendor/media/bootanimation.zip",
]

# placeholders for globals that will be set by ensure_work_dirs()
WORK_DIR = None
EXTRACT_DIR = None
PULLED_ZIP = None
CREATED_ZIP_DEFAULT = None


def _frame_sort_key(path_or_name: str):
    """Sort key for frame files: numeric suffix first, then lexicographic fallback."""
    nm = os.path.basename(path_or_name)
    nums = re.findall(r"\d+", nm)
    if nums:
        try:
            return (0, int(nums[-1]), "")
        except Exception:
            pass
    return (1, 0, nm.lower())


class FrameLoaderWorker(QThread):
    progress = pyqtSignal(int, int)  # current, total
    finished_seq = pyqtSignal(list, int)  # sequence, frame_ms
    error = pyqtSignal(str)

    def __init__(self, folders: List[str], width: int, height: int, fps: int):
        super().__init__()
        self.folders = folders
        self.width = width
        self.height = height
        self.fps = fps

    def run(self):
        try:
            valid_folders = [d for d in self.folders if os.path.isdir(d)]
            if not valid_folders:
                self.error.emit("No valid frame folders found.")
                return

            frame_ms = int(1000 / max(1, self.fps))
            all_files = []
            for d in valid_folders:
                files = [os.path.join(d, f) for f in os.listdir(d) if f.lower().endswith((".png", ".jpg", ".jpeg", ".webp"))]
                files.sort(key=_frame_sort_key)
                all_files.extend(files)

            if not all_files:
                self.error.emit("No frames found.")
                return

            total = len(all_files)
            seq = []
            for i, fpath in enumerate(all_files):
                pix = QPixmap(fpath)
                if pix.isNull():
                    continue
                pix = pix.scaled(self.width, self.height, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
                seq.append((pix, frame_ms, os.path.basename(fpath)))
                self.progress.emit(i + 1, total)

            self.finished_seq.emit(seq, frame_ms)
        except Exception as e:
            self.error.emit(str(e))


class FuncThread(QThread):
    done = pyqtSignal(object, object)

    def __init__(self, fn, *args, **kwargs):
        super().__init__()
        self.fn = fn
        self.args = args
        self.kwargs = kwargs

    def run(self):
        try:
            res = self.fn(*self.args, **self.kwargs)
            self.done.emit(res, None)
        except Exception as e:
            self.done.emit(None, e)


def ensure_work_dirs():
    """
    Initialize module-level WORK_DIR, EXTRACT_DIR, PULLED_ZIP, CREATED_ZIP_DEFAULT.
    """
    global WORK_DIR, EXTRACT_DIR, PULLED_ZIP, CREATED_ZIP_DEFAULT
    if not WORK_DIR:
        WORK_DIR = tempfile.mkdtemp(prefix="qadb_work_")
    
    EXTRACT_DIR = os.path.join(WORK_DIR, "extracted")
    PULLED_ZIP = os.path.join(WORK_DIR, "bootanimation.zip")
    CREATED_ZIP_DEFAULT = os.path.join(WORK_DIR, "new_bootanimation.zip")
    
    # ensure extract dir exists
    os.makedirs(EXTRACT_DIR, exist_ok=True)


def cleanup_work_dirs():
    global WORK_DIR
    try:
        if WORK_DIR and os.path.isdir(WORK_DIR):
            shutil.rmtree(WORK_DIR)
    except Exception:
        pass


def find_remote_path_sync(adb_cmd: str = None) -> Optional[str]:
    """Check common paths on device using adb shell ls with root privileges."""
    for p in BOOT_PATHS:
        try:
            proc = ADBClient.instance().run_shell(["su", "-c", f'ls "{p}"'], use_serial=True, timeout=6.0)
        except Exception:
            continue
        out = (proc.stdout or "") + (proc.stderr or "")
        if proc.returncode == 0 and "No such file or directory" not in out:
            return p
    return None

find_bootanimation_path = find_remote_path_sync


def pull_root_zip_sync(remote_path: str, adb_cmd: str = None, local_dest: str = None) -> bool:
    """
    Pull bootanimation.zip using root-copy to /data/local/tmp then adb pull.
    local_dest provided (module-level PULLED_ZIP expected to be set).
    """
    tmp_remote = "/data/local/tmp/bootanimation_quickadb.zip"
    if local_dest is None:
        raise RuntimeError("local_dest must be specified")
    
    q_remote = shlex.quote(remote_path)
    q_tmp = shlex.quote(tmp_remote)
    try:
        cp = ADBClient.instance().run_shell(["su", "-c", f"cp {q_remote} {q_tmp} && chmod 0644 {q_tmp}"], use_serial=True, timeout=25.0)
        if cp.returncode == 0:
            pull = ADBClient.instance().pull(tmp_remote, local_dest, use_serial=True, timeout=90.0)
            if pull.returncode == 0 and os.path.exists(local_dest):
                ADBClient.instance().run_shell(["su", "-c", f"rm -f {q_tmp}"], use_serial=True, timeout=10.0)
                return True
    except Exception:
        pass

    try:
        proc1 = ADBClient.instance().run_shell(["su", "-c", f"cp {q_remote} {q_tmp}"], use_serial=True, timeout=20.0)
        if proc1.returncode == 0:
            proc2 = ADBClient.instance().run_shell(["su", "-c", f"chmod 0644 {q_tmp}"], use_serial=True, timeout=10.0)
            if proc2.returncode == 0:
                pull = ADBClient.instance().pull(tmp_remote, local_dest, use_serial=True, timeout=90.0)
                if pull.returncode == 0 and os.path.exists(local_dest):
                    ADBClient.instance().run_shell(["su", "-c", f"rm -f {q_tmp}"], use_serial=True, timeout=10.0)
                    return True
    except Exception:
        pass
    return False


def extract_zip(zip_path: str, extract_to: str):
    """
    Safely extract zip members to extract_to, guarding against Zip Slip traversal.
    """
    target_root = os.path.realpath(extract_to)
    with zipfile.ZipFile(zip_path, "r") as zf:
        for member in zf.infolist():
            member_path = os.path.realpath(os.path.join(target_root, member.filename))
            if not (member_path == target_root or member_path.startswith(target_root + os.sep)):
                raise ValueError(f"Unsafe zip member path detected: {member.filename}")
        zf.extractall(extract_to)


def parse_pulled_zip_sync(zip_path: str) -> Optional[Dict]:
    """
    Extract zip into EXTRACT_DIR and parse desc.txt. Returns info dict or None.
    """
    if not zip_path or not os.path.exists(zip_path):
        return None
    # ensure extract dir empty
    shutil.rmtree(EXTRACT_DIR, ignore_errors=True)
    os.makedirs(EXTRACT_DIR, exist_ok=True)
    try:
        extract_zip(zip_path, EXTRACT_DIR)
    except Exception:
        return None
    desc = os.path.join(EXTRACT_DIR, "desc.txt")
    if not os.path.exists(desc):
        return None
    try:
        with open(desc, "r", encoding="utf-8", errors="ignore") as f:
            lines = [ln.strip() for ln in f.read().splitlines() if ln.strip()]
        w, h, fps = map(int, lines[0].split()[:3])
    except Exception:
        return None
    parts = []
    for ln in lines[1:]:
        tok = ln.split()
        if len(tok) < 3:
            continue
        mode = tok[0]
        loops = int(tok[1]) if tok[1].isdigit() else 1
        folder = tok[2]
        pause = int(tok[3]) if len(tok) > 3 and tok[3].isdigit() else 0
        candidate = os.path.join(EXTRACT_DIR, folder)
        folder_path = candidate if os.path.isdir(candidate) else None
        frame_count = 0
        if folder_path:
            frame_count = len([f for f in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path, f))])
        parts.append({
            "mode": mode, "loops": loops, "folder": folder, "pause": pause,
            "frame_count": frame_count, "folder_path": folder_path
        })
    return {"width": w, "height": h, "fps": fps, "parts": parts}


def extract_video_frames_sync(video_path: str, width: int, height: int, ffmpeg_path: str, fps: Optional[int] = None) -> str:
    """
    Extract frames from video using ffmpeg into a temporary directory and return that dir path.
    The temp frames directory is retained in self._last_created_frames_dir for full-resolution ZIP export.
    Raises on failure.
    """
    if not os.path.isfile(video_path):
        raise FileNotFoundError("Video file missing")
    # resolve ffmpeg path: prefer provided exact path, otherwise search PATH
    ff = ffmpeg_path.strip() if ffmpeg_path else ""
    if ff and os.path.isfile(ff):
        ffmpeg_bin = ff
    else:
        ffmpeg_bin = shutil.which(ff) or shutil.which("ffmpeg")
    if not ffmpeg_bin:
        raise FileNotFoundError("ffmpeg not found")
    out_dir = tempfile.mkdtemp(prefix="bootanim_vid_", dir=WORK_DIR)
    out_pattern = os.path.join(out_dir, "%09d.png")
    args = [ffmpeg_bin, "-y", "-i", video_path]
    # force FPS if provided
    if fps and isinstance(fps, int) and fps > 0:
        args += ["-r", str(fps)]
    if width > 0 and height > 0:
        args += ["-vf", f"scale={width}:{height}:flags=lanczos"]
    args += [out_pattern]
    # Windows specific: Create a new process group and hide the console window.
    creationflags = 0
    if os.name == 'nt':
        creationflags = (
            subprocess.CREATE_NEW_PROCESS_GROUP |
            subprocess.CREATE_NO_WINDOW
        )

    proc = subprocess.run(args, capture_output=True, text=True, timeout=600, creationflags=creationflags)
    if proc.returncode != 0:
        try:
            shutil.rmtree(out_dir)
        except Exception:
            pass
        raise RuntimeError(f"ffmpeg failed: {proc.stderr[:1000] or proc.stdout[:1000]}")
    return out_dir


def extract_gif_frames_sync(gif_path: str, width: int, height: int, fps: Optional[int] = None) -> str:
    """
    Extract frames from GIF into a temporary folder using Pillow and return that dir.
    """
    if not os.path.isfile(gif_path):
        raise FileNotFoundError("GIF file missing")
    out_dir = tempfile.mkdtemp(prefix="bootanim_gif_", dir=WORK_DIR)
    im = Image.open(gif_path)
    i = 0
    for frame in ImageSequence.Iterator(im):
        frame = frame.convert("RGBA")
        if width > 0 and height > 0:
            frame = frame.resize((width, height), Image.Resampling.LANCZOS)
        frame.save(os.path.join(out_dir, f"{i:09d}.png"))
        i += 1
    if i == 0:
        shutil.rmtree(out_dir)
        raise RuntimeError("No frames extracted from GIF")
    return out_dir


def generate_frames_from_video_sync(video_path: str, width: int = 0, height: int = 0, ffmpeg_path: str = "", fps: Optional[int] = None) -> str:
    """
    Extract frames from video using ffmpeg into a temporary directory and return that dir path.
    The temp frames directory is retained in self._last_created_frames_dir for full-resolution ZIP export.
    """
    return extract_video_frames_sync(video_path, width, height, ffmpeg_path, fps)


def push_and_install_bootanimation_sync(local_zip: str, remote_final: str, adb_cmd: str = None) -> bool:
    """
    Push local bootanimation.zip to device and install to remote_final using root copy.
    Shell-quotes remote paths to prevent command injection.
    """
    if not os.path.exists(local_zip):
        raise FileNotFoundError(f"Local file not found: {local_zip}")
    if not remote_final:
        raise ValueError("Remote destination path must be provided")

    remote_tmp = "/data/local/tmp/quickadb_push_bootanim.zip"
    target_dir = os.path.dirname(remote_final)

    q_remote_tmp = shlex.quote(remote_tmp)
    q_target_dir = shlex.quote(target_dir)
    q_remote_final = shlex.quote(remote_final)

    push_res = _run_adb(["push", local_zip, remote_tmp])
    if not push_res or getattr(push_res, "returncode", 1) != 0:
        return False

    try:
        cp_cmd = f'su -c "cp {q_remote_tmp} {q_remote_final} && chmod 0644 {q_remote_final}"'
        proc = _run_adb(["shell", cp_cmd])
        if proc and getattr(proc, "returncode", 1) == 0:
            return True

        # Remount rw and retry
        _run_adb(["shell", f'su -c "mount -o remount,rw {q_target_dir} || mount -o remount,rw /system || mount -o remount,rw /system_root || true"'])
        proc2 = _run_adb(["shell", cp_cmd])
        return bool(proc2 and getattr(proc2, "returncode", 1) == 0)
    finally:
        _run_adb(["shell", f'su -c "rm -f {q_remote_tmp}"'])


# ---------- Module creation helpers ----------
def _make_zip_with_permissions(root_dir: str, out_zip: str, perms: Dict[str, int] = None):
    """
    Create zip file from root_dir and set unix permissions for files specified in perms (relpath->mode).
    perms is optional dict mapping relative path inside zip to unix mode (e.g. 0o755).
    """
    if perms is None:
        perms = {}
    with zipfile.ZipFile(out_zip, "w", compression=zipfile.ZIP_STORED) as zf:
        for rootp, dirs, files in os.walk(root_dir):
            for fn in files:
                full = os.path.join(rootp, fn)
                rel = os.path.relpath(full, root_dir)
                # zipfile internally uses forward slashes, so normalize for the lookup
                rel_zip = rel.replace("\\", "/")
                zf.write(full, rel_zip)
                # set external attr for permissions if provided
                if rel_zip in perms:
                    info = zf.getinfo(rel_zip)
                    # mode in upper 16 bits
                    info.external_attr = (perms[rel_zip] & 0xFFFF) << 16


def create_module_sync(module_meta: Dict[str, str], save_zip: str, created_boot_zip: str, remote_path: str, alias: str):
    """
    Build a flashable module zip that places created_boot_zip into the device remote_path.
    Returns success message or raises.
    """
    if not remote_path:
        raise RuntimeError("Remote path unknown. Find/pull the device bootanimation first.")
    if not created_boot_zip or not os.path.exists(created_boot_zip):
        raise RuntimeError("Created bootanimation.zip missing. Create it first.")

    tmp_mod = tempfile.mkdtemp(prefix="qadb_module_")
    try:
        # Determine internal module path components (drop leading slash)
        rp = remote_path.lstrip("/")
        parts = rp.split("/")[:-1]  # directory components (exclude filename)
        target_rel_dir = os.path.join(*parts) if parts else ""
        mod_target_dir = os.path.join(tmp_mod, target_rel_dir)
        os.makedirs(mod_target_dir, exist_ok=True)

        # Copy created bootanimation.zip into the module
        target_filename = os.path.basename(remote_path)
        shutil.copy2(created_boot_zip, os.path.join(mod_target_dir, target_filename))

        # module.prop generation
        mod_id = module_meta.get("id") or f"quickadb.bootanim.{int(time.time())}"
        mod_name = module_meta.get("name") or "QuickADB Boot Animation"
        mod_version = module_meta.get("version") or "1.0"
        mod_author = module_meta.get("author") or "QuickADB"
        mod_desc = module_meta.get("description", "") + f"\nMade with {alias}"

        mod_prop = [
            f"id={mod_id}",
            f"name={mod_name}",
            f"version={mod_version}",
            f"author={mod_author}",
            f"description={mod_desc}"
        ]
        with open(os.path.join(tmp_mod, "module.prop"), "w", encoding="utf-8") as f:
            f.write("\n".join(mod_prop))

        # post-fs-data.sh script to set permission for the installed file (executable)
        target_full = remote_path  # exact path to chmod on device
        post_sh = f"#!/sbin/sh\n# Ensure permission for bootanimation\nchmod 0644 \"{target_full}\" || true\nexit 0\n"
        sh_path = os.path.join(tmp_mod, "post-fs-data.sh")
        with open(sh_path, "w", encoding="utf-8") as f:
            f.write(post_sh)
        # create a short README
        readme = f"{mod_name}\n\nThis module installs a custom bootanimation at: {remote_path}\n{mod_desc}\n"
        with open(os.path.join(tmp_mod, "README.txt"), "w", encoding="utf-8") as f:
            f.write(readme)

        # create zip and set perms: post-fs-data.sh -> 0o755, bootanimation.zip -> 0o644
        perms = {}
        rel_post = os.path.relpath(sh_path, tmp_mod)
        rel_boot = os.path.join(target_rel_dir, target_filename) if target_rel_dir else target_filename
        perms[rel_post] = 0o755
        perms[rel_boot] = 0o644
        _make_zip_with_permissions(tmp_mod, save_zip, perms=perms)
        return f"Module created: {save_zip}"
    finally:
        try:
            shutil.rmtree(tmp_mod)
        except Exception:
            pass


# ---------- GUI and main widget ----------
class ModuleDialog(QDialog):
    """
    Dialog for module metadata; 'Create module' asks for save location and accepts.
    After exec(), dialog.save_path (str) will be set or None.
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Create Flashable Module - Module Properties")
        self.setMinimumWidth(480)
        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.id_edit = QLineEdit()
        self.name_edit = QLineEdit("QuickADB Boot Animation Module")
        self.version_edit = QLineEdit("1.0")
        self.author_edit = QLineEdit("QuickADB")
        self.desc_edit = QPlainTextEdit("Install custom bootanimation created with QuickADB.")
        form.addRow("Module ID:", self.id_edit)
        form.addRow("Name:", self.name_edit)
        form.addRow("Version:", self.version_edit)
        form.addRow("Author:", self.author_edit)
        form.addRow("Description:", self.desc_edit)
        layout.addLayout(form)

        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        btns.accepted.connect(self._on_ok)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)
        self.save_path: Optional[str] = None

    def _on_ok(self):
        # ask for save path before accepting
        fn, _ = QFileDialog.getSaveFileName(self, "Save module zip", "", "ZIP Files (*.zip)")
        if not fn:
            return  # don't accept, let user pick
        if not fn.lower().endswith(".zip"):
            fn += ".zip"
        self.save_path = fn
        self.accept()

    def get_meta(self):
        return {
            "id": self.id_edit.text().strip(),
            "name": self.name_edit.text().strip(),
            "version": self.version_edit.text().strip(),
            "author": self.author_edit.text().strip(),
            "description": self.desc_edit.toPlainText().strip(),
        }


class PushDialog(QDialog):
    """
    Minimal dialog presenting push options:
      - Push created ZIP (if available)
      - Select & push specific ZIP
    Returns tuple (choice, path) where choice is 'created' or 'select' or None.
    """
    def __init__(self, parent=None, created_path: Optional[str] = None):
        super().__init__(parent)
        self.setWindowTitle("Push bootanimation.zip")
        self.created_path = created_path
        self.choice = None
        self.path = None
        self._build()

    def _build(self):
        layout = QVBoxLayout(self)
        info = QLabel("Choose which ZIP to push to device:")
        layout.addWidget(info)
        btn_row = QHBoxLayout()
        self.btn_created = QPushButton("Push created ZIP")
        self.btn_created.clicked.connect(self._on_created)
        self.btn_select = QPushButton("Select & Push ZIP")
        self.btn_select.clicked.connect(self._on_select)
        btn_row.addWidget(self.btn_created)
        btn_row.addWidget(self.btn_select)
        layout.addLayout(btn_row)
        self.cancel_btn = QPushButton("Cancel")
        self.cancel_btn.clicked.connect(self.reject)
        layout.addWidget(self.cancel_btn)
        if not self.created_path or not os.path.exists(self.created_path):
            self.btn_created.setEnabled(False)

    def _on_created(self):
        self.choice = "created"
        self.path = self.created_path
        self.accept()

    def _on_select(self):
        fn, _ = QFileDialog.getOpenFileName(self, "Select bootanimation.zip to push", "", "ZIP files (*.zip);;All Files (*)")
        if not fn:
            return
        self.choice = "select"
        self.path = fn
        self.accept()


def run_bootanim_creator(parent=None):
    """Entry point for QuickADB to launch the Boot Animation Creator."""
    window = BootAnimWidget()
    window.show()
    return window

class BootAnimWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("QuickADB Boot Animation Creator")
        self.setMinimumSize(980, 720)
        ThemeManager.apply_theme(self)

        # create temp work dirs
        ensure_work_dirs()
        self.adb_cmd = ToolPaths.instance().adb  # looked up now, not at import, so a fresh download is used

        self.remote_path: Optional[str] = None
        self.current_info: Optional[Dict] = None
        self.created_zip_path = CREATED_ZIP_DEFAULT
        self.backup_dir = os.path.join(root_dir, "bootanim_backups")
        os.makedirs(self.backup_dir, exist_ok=True)

        self.seq_current: List[Tuple[QPixmap, int, str]] = []
        self.seq_created: List[Tuple[QPixmap, int, str]] = []

        self.timer_current = QTimer(self)
        self.timer_created = QTimer(self)
        self.timer_current.timeout.connect(self._tick_current)
        self.timer_created.timeout.connect(self._tick_created)
        self.play_index_current = 0
        self.play_index_created = 0
        self.playing_current = False
        self.playing_created = False

        self._threads: List[QThread] = []

        self.ffmpeg_resolved_path = shutil.which("ffmpeg") or ""
        self.ffmpeg_path = self.ffmpeg_resolved_path

        # selected animation file (video or gif) to be previewed / decoded
        self.selected_anim_file: Optional[str] = None
        self._selected_video_path: Optional[str] = None

        # remember last frames dir briefly before cleanup (we will delete extracted frames after loading into RAM)
        self._last_created_frames_dir: Optional[str] = None

        self._build_ui()
        # setup status bar (manually since QWidget doesn't have it by default, but we'll add it to layout)
        QTimer.singleShot(150, self._startup_ffmpeg_check)

    @property
    def selected_video_path(self) -> Optional[str]:
        return self._selected_video_path or self.selected_anim_file

    @selected_video_path.setter
    def selected_video_path(self, val: Optional[str]):
        self._selected_video_path = val
        self.selected_anim_file = val

    def generate_frames_from_video_sync(self, video_path: str, fps: Optional[int] = None) -> str:
        """
        Extract full-resolution frames from video using ffmpeg into a temporary directory.
        The temp frames directory is retained in self._last_created_frames_dir for full-resolution ZIP export.
        """
        if not video_path or not os.path.exists(video_path):
            raise FileNotFoundError(f"Video file missing: {video_path}")
        try:
            w = int(self.width_spin.value()) if hasattr(self, "width_spin") else 0
            h = int(self.height_spin.value()) if hasattr(self, "height_spin") else 0
        except Exception:
            w, h = 720, 240
        if fps is None:
            try:
                fps = int(self.fps_spin.value()) if hasattr(self, "fps_spin") else 30
            except Exception:
                fps = 30
        ffmpeg_bin = ""
        if hasattr(self, "ffmpeg_edit"):
            ffmpeg_bin = self.ffmpeg_edit.text().strip()
        if not ffmpeg_bin:
            ffmpeg_bin = getattr(self, "ffmpeg_resolved_path", "") or shutil.which("ffmpeg") or ""

        if video_path.lower().endswith(".gif"):
            out_dir = extract_gif_frames_sync(video_path, w, h, fps)
        else:
            out_dir = extract_video_frames_sync(video_path, w, h, ffmpeg_bin, fps)

        if self._last_created_frames_dir and os.path.isdir(self._last_created_frames_dir) and self._last_created_frames_dir != out_dir:
            try:
                shutil.rmtree(self._last_created_frames_dir)
            except Exception:
                pass
        self._last_created_frames_dir = out_dir
        return out_dir

    def _build_ui(self):
        root = QVBoxLayout(self)

        # --- Top row buttons ---
        top = QHBoxLayout()
        btn_size = (205, 30)  # bigger buttons

        self.find_btn = QPushButton("Find Device Bootanim (Root)")
        self.find_btn.setFixedSize(*btn_size)
        self.find_btn.clicked.connect(self.find_and_load)

        self.select_anim_btn = QPushButton("Select MP4/GIF for Create/Preview")
        self.select_anim_btn.setFixedSize(*btn_size)
        self.select_anim_btn.clicked.connect(self.select_animation_file)

        top.addWidget(self.find_btn)
        top.addWidget(self.select_anim_btn)
        top.addStretch()
        root.addLayout(top)

        # --- Mid section ---
        mid = QHBoxLayout()
        left_col = QVBoxLayout()

        # Animation Properties
        props_grp = QGroupBox("Animation Properties")
        props_layout = QHBoxLayout()
        self.width_spin = QSpinBox(); self.width_spin.setRange(16, 4096); self.width_spin.setValue(720)
        self.height_spin = QSpinBox(); self.height_spin.setRange(16, 4096); self.height_spin.setValue(240)
        self.fps_spin = QSpinBox(); self.fps_spin.setRange(1, 60); self.fps_spin.setValue(30)
        self.preview_btn = QPushButton("Preview Selected File"); self.preview_btn.setFixedSize(180, 30); self.preview_btn.clicked.connect(self.preview_selected_animation)
        props_layout.addWidget(QLabel("Width")); props_layout.addWidget(self.width_spin)
        props_layout.addWidget(QLabel("Height")); props_layout.addWidget(self.height_spin)
        props_layout.addWidget(QLabel("FPS")); props_layout.addWidget(self.fps_spin)
        props_layout.addWidget(self.preview_btn)
        props_grp.setLayout(props_layout)
        left_col.addWidget(props_grp)

        # FFmpeg section
        ff_grp = QGroupBox("FFmpeg")
        ff_layout = QHBoxLayout()
        self.ffmpeg_edit = QLineEdit(self.ffmpeg_resolved_path)
        self.ffmpeg_edit.setPlaceholderText("ffmpeg path (or leave blank to use PATH)")
        self.ff_browse = QPushButton("Browse"); self.ff_browse.setFixedSize(80, 28); self.ff_browse.clicked.connect(self.browse_ffmpeg)
        self.ff_check = QPushButton("Check"); self.ff_check.setFixedSize(80, 28); self.ff_check.clicked.connect(self.check_ffmpeg)
        ff_layout.addWidget(self.ffmpeg_edit); ff_layout.addWidget(self.ff_browse); ff_layout.addWidget(self.ff_check)
        ff_grp.setLayout(ff_layout)
        left_col.addWidget(ff_grp)

        # Created/Backup Paths section (4x2 grid)
        created_grp = QGroupBox("Created / Backup Actions")
        created_layout = QGridLayout()

        # Create button
        self.create_zip_btn = QPushButton("Create bootanimation.zip from frames")
        self.create_zip_btn.clicked.connect(self.create_bootanimation_zip)

        # Backup button (single backup flow)
        self.backup_btn = QPushButton("Backup stock boot animation")
        self.backup_btn.clicked.connect(self.backup_stock_bootanimation)

        # Push button (opens dialog)
        self.push_zip_btn = QPushButton("Push bootanimation.zip to device")
        self.push_zip_btn.clicked.connect(self.push_zip_flow)

        self.create_module_btn = QPushButton("Create Flashable Module")
        self.create_module_btn.clicked.connect(self.create_flashable_module_flow)
        
        self.reload_btn = QPushButton("Reload Frames from Workdir")
        self.reload_btn.clicked.connect(self.reload_frames_from_workdir)
        
        self.clear_btn = QPushButton("Clear Frames / Workdir")
        self.clear_btn.clicked.connect(self.clear_all_frames)
        
        self.workdir_btn = QPushButton("Open Work Directory")
        self.workdir_btn.clicked.connect(self.open_work_directory)

        # Layout the 4x2 grid
        created_layout.addWidget(self.create_zip_btn, 0, 0)
        created_layout.addWidget(self.backup_btn, 0, 1)
        created_layout.addWidget(self.push_zip_btn, 1, 0)
        created_layout.addWidget(self.create_module_btn, 1, 1)
        created_layout.addWidget(self.reload_btn, 2, 0)
        created_layout.addWidget(self.workdir_btn, 2, 1)
        created_layout.addWidget(self.clear_btn, 3, 0)

        created_grp.setLayout(created_layout)
        left_col.addWidget(created_grp)

        # Logging area
        self.log_text = QTextEdit(); self.log_text.setReadOnly(True); self.log_text.setFixedHeight(220)
        left_col.addWidget(self.log_text)

        mid.addLayout(left_col, stretch=0)

        # Right preview columns
        right_col = QHBoxLayout()
        preview_w = 220
        preview_h = int(preview_w * 20 / 9)

        # Current device preview
        cur_group = QVBoxLayout()
        cur_group.addWidget(QLabel("Current (device)", alignment=Qt.AlignmentFlag.AlignCenter))
        self.cur_label = QLabel(); self.cur_label.setFixedSize(preview_w, preview_h); self.cur_label.setStyleSheet("background:#0d0d0d;"); self.cur_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        cur_group.addWidget(self.cur_label, alignment=Qt.AlignmentFlag.AlignCenter)
        
        self.cur_meta = QLabel("Frame: -"); self.cur_meta.setAlignment(Qt.AlignmentFlag.AlignCenter); self.cur_meta.setStyleSheet("font-size: 9px; color: #888;")
        cur_group.addWidget(self.cur_meta)
        self.cur_seek = QSlider(Qt.Orientation.Horizontal); self.cur_seek.setEnabled(False)
        self.cur_seek.sliderMoved.connect(lambda val: self._on_seek_moved("current", val))
        cur_group.addWidget(self.cur_seek)

        cur_btn_row = QHBoxLayout()
        self.cur_play_btn = QPushButton("▶"); self.cur_play_btn.setFixedSize(40, 28); self.cur_play_btn.clicked.connect(self.toggle_current)
        cur_btn_row.addWidget(self.cur_play_btn); cur_btn_row.addStretch()
        cur_group.addLayout(cur_btn_row)
        right_col.addLayout(cur_group)

        # Created local preview
        new_group = QVBoxLayout()
        new_group.addWidget(QLabel("Created (local preview)", alignment=Qt.AlignmentFlag.AlignCenter))
        self.new_label = QLabel(); self.new_label.setFixedSize(preview_w, preview_h); self.new_label.setStyleSheet("background:#0d0d0d;"); self.new_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        new_group.addWidget(self.new_label, alignment=Qt.AlignmentFlag.AlignCenter)
        
        self.new_meta = QLabel("Frame: -"); self.new_meta.setAlignment(Qt.AlignmentFlag.AlignCenter); self.new_meta.setStyleSheet("font-size: 9px; color: #888;")
        new_group.addWidget(self.new_meta)
        self.new_seek = QSlider(Qt.Orientation.Horizontal); self.new_seek.setEnabled(False)
        self.new_seek.sliderMoved.connect(lambda val: self._on_seek_moved("created", val))
        new_group.addWidget(self.new_seek)

        new_btn_row = QHBoxLayout()
        self.new_play_btn = QPushButton("▶"); self.new_play_btn.setFixedSize(40, 28); self.new_play_btn.clicked.connect(self.toggle_created)
        new_btn_row.addWidget(self.new_play_btn); new_btn_row.addStretch()
        new_group.addLayout(new_btn_row)
        right_col.addLayout(new_group)

        mid.addLayout(right_col, stretch=0)
        root.addLayout(mid)


    def log(self, msg: str):
        ts = time.strftime("%H:%M:%S")
        self.log_text.append(f"[{ts}] {msg}")
        self.log_text.ensureCursorVisible()

    def _startup_ffmpeg_check(self):
        path = shutil.which("ffmpeg")
        if path:
            self.log(f"ffmpeg found in PATH")
            self._check_ffmpeg_version(path, silent=True)
        else:
            self.log("ffmpeg not found in PATH")

    def browse_ffmpeg(self):
        p, _ = QFileDialog.getOpenFileName(self, "Locate ffmpeg binary")
        if not p:
            return
        self.ffmpeg_edit.setText(p)
        self.check_ffmpeg()

    def check_ffmpeg(self):
        p = self.ffmpeg_edit.text().strip() or shutil.which("ffmpeg") or ""
        if not p:
            QMessageBox.warning(self, "FFmpeg", "FFmpeg not set and not found in PATH.")
            return
        self._check_ffmpeg_version(p, silent=False)

    def _check_ffmpeg_version(self, p, silent=False):
        # Windows specific: Create a new process group and hide the console window.
        creationflags = 0
        if os.name == 'nt':
            creationflags = (
                subprocess.CREATE_NEW_PROCESS_GROUP |
                subprocess.CREATE_NO_WINDOW
            )

        try:
            proc = subprocess.run([p, "-version"], capture_output=True, text=True, timeout=6, creationflags=creationflags)
            out = proc.stdout or proc.stderr or ""
            first = out.splitlines()[0] if out.splitlines() else out.strip()
            self.log(f"ffmpeg: {first}")
            self.ffmpeg_resolved_path = p
            self.ffmpeg_path = p
            self.ffmpeg_edit.setText(p)
        except Exception as e:
            self.log(f"ffmpeg check failed: {e}")
            if not silent:
                QMessageBox.critical(self, "FFmpeg", f"ffmpeg check failed: {e}")

    def _start_thread(self, t: QThread):
        self._threads.append(t)
        def cleanup():
            try:
                self._threads.remove(t)
            except ValueError:
                pass
        t.finished.connect(cleanup)
        if hasattr(t, "done"):
            t.done.connect(lambda *_: cleanup())
        t.start()
        return t

    # ---------- find/pull/parse flow ----------
    def find_and_load(self):
        self.log("Detecting bootanimation on device (root-only)...")
        t = FuncThread(find_remote_path_sync, self.adb_cmd)
        t.done.connect(self._on_find_done)
        self._start_thread(t)

    def _on_find_done(self, result, error):
        if error:
            self.log(f"Find failed: {error}")
            QMessageBox.critical(self, "Find failed", str(error))
            return
        found = result
        if not found:
            self.log("No bootanimation found.")
            QMessageBox.information(self, "Not found", "No bootanimation found in common locations.")
            return
        self.remote_path = found
        self.log(f"Found: {found}")
        self.pull_remote()

    def pull_remote(self):
        if not getattr(self, "remote_path", None):
            QMessageBox.warning(self, "No target", "Run Find first.")
            return
        self.log(f"Pulling {self.remote_path} ...")
        t = FuncThread(pull_root_zip_sync, self.remote_path, self.adb_cmd, PULLED_ZIP)
        t.done.connect(self._on_pull_done)
        self._start_thread(t)

    def _on_pull_done(self, result, error):
        if error:
            self.log(f"Pull failed: {error}")
            QMessageBox.critical(self, "Pull failed", str(error))
            return
        ok = result
        if not ok:
            self.log("Pull reported failure.")
            QMessageBox.critical(self, "Pull failed", "Could not pull bootanimation.zip (root flow).")
            return
        self.log(f"Pulled: {PULLED_ZIP}")
        t = FuncThread(parse_pulled_zip_sync, PULLED_ZIP)
        t.done.connect(self._on_parse_done)
        self._start_thread(t)

    def _resolve_folder_path(self, folder_name: str) -> Optional[str]:
        if not folder_name:
            return None
        token = folder_name.strip().lstrip("./").rstrip("/")
        candidate = os.path.normpath(os.path.join(EXTRACT_DIR, token))
        if os.path.isdir(candidate):
            return candidate
        if token.isdigit():
            for t in (f"part{token}", f"p{token}", token):
                c = os.path.join(EXTRACT_DIR, t)
                if os.path.isdir(c):
                    return c
        base = os.path.basename(token)
        # Collect all subdirectories in a single walk, then apply match strategies in priority order.
        all_dirs: List[Tuple[str, str]] = []  # (dirpath, dirname)
        for rootp, dirs, _ in os.walk(EXTRACT_DIR):
            for d in dirs:
                all_dirs.append((os.path.join(rootp, d), d))
        # 1. Exact name match
        for path, name in all_dirs:
            if name == token:
                return path
        # 2. Numeric suffix match (only when token is a digit string)
        if token.isdigit():
            for path, name in all_dirs:
                if name.endswith(token):
                    return path
        # 3. Case-insensitive substring match
        for path, name in all_dirs:
            if token.lower() in name.lower():
                return path
        # 4. Basename exact match
        if base:
            for path, name in all_dirs:
                if name == base:
                    return path
        return None

    def _on_parse_done(self, result, error):
        if error:
            self.log(f"Parse failed: {error}")
            QMessageBox.critical(self, "Parse failed", str(error))
            return
        info = result
        if not info:
            self.log("Parse returned no info (desc.txt missing?).")
            QMessageBox.critical(self, "Parse failed", "desc.txt missing or invalid in pulled zip.")
            return
        self.current_info = info
        self.log(f"Parsed boot animation: {info['width']}x{info['height']}@{info['fps']}, parts: {len(info['parts'])}")
        self.build_sequence_from_info(info, which="current")

    # ---------- sequence builder (unchanged flatten/ordering approach) ----------
    def build_sequence_from_info(self, info: Dict, which: str = "current"):
        fps = int(info.get("fps", 30) or 30)
        
        folders = []
        for p in info.get("parts", []):
            folder_name = p.get("folder") if isinstance(p, dict) else str(p)
            folder_path = self._resolve_folder_path(folder_name)
            if folder_path and os.path.isdir(folder_path):
                frames = sorted([f for f in os.listdir(folder_path) if f.lower().endswith((".png", ".jpg", ".jpeg"))])
                if frames and folder_path not in folders:
                    folders.append(folder_path)

        if not folders and os.path.isdir(EXTRACT_DIR):
            def part_index(name: str):
                m = re.fullmatch(r"part(\d+)", name, flags=re.IGNORECASE)
                return int(m.group(1)) if m else None
            
            part_dirs = []
            for name in os.listdir(EXTRACT_DIR):
                idx = part_index(name)
                if idx is not None:
                    p = os.path.join(EXTRACT_DIR, name)
                    if os.path.isdir(p):
                        part_dirs.append((idx, p))
            part_dirs.sort(key=lambda t: t[0])
            folders = [p for _, p in part_dirs]

        if not folders:
            self.log("[WARN] No partN folders found.")
            return

        target_w = self.cur_label.width() if which == "current" else self.new_label.width()
        target_h = self.cur_label.height() if which == "current" else self.new_label.height()
        
        self.log(f"[INFO] Starting async frame loader for '{which}'...")
        self._launch_loader(folders, target_w, target_h, fps, which)

    def _launch_loader(self, folders: list, target_w: int, target_h: int, fps: int, which: str):
        """Create, wire, and start a FrameLoaderWorker."""
        loader = FrameLoaderWorker(folders, target_w, target_h, fps)
        loader._which = which
        loader.finished_seq.connect(self._on_loader_done)
        loader.error.connect(lambda e: self.log(f"[ERROR] Loader error: {e}"))
        self._start_thread(loader)

    def _on_loader_done(self, seq, frame_ms):
        loader = self.sender()
        which = getattr(loader, "_which", "created")
        if not seq:
            self.log(f"[WARN] No frames loaded for outline ('{which}').")
            QMessageBox.information(self, "Preview", "No frames were loaded for preview. See log for details.")
            return

        self.log(f"[INFO] Loaded {len(seq)} frames for '{which}'.")
        
        if which == "current":
            self.seq_current = seq
            self.play_index_current = 0
            self.frame_ms_current = frame_ms
            self.cur_seek.setRange(0, len(seq) - 1)
            self.cur_seek.setEnabled(True)
            self.start_current()
        else:
            self.seq_created = seq
            self.play_index_created = 0
            self.frame_ms_created = frame_ms
            self.new_seek.setRange(0, len(seq) - 1)
            self.new_seek.setEnabled(True)
            self.start_created()

    # ---------- select animation ----------
    def select_animation_file(self):
        fn, _ = QFileDialog.getOpenFileName(self, "Select .mp4 or .gif", "", "Animations (*.mp4 *.mkv *.mov *.avi *.gif);;All Files (*)")
        if not fn:
            return
        self.selected_anim_file = fn
        self.log(f"Selected animation file: {fn}")
        QMessageBox.information(self, "Selected", f"Selected: {os.path.basename(fn)}\nClick Preview to render using current Width/Height/FPS")

    # ---------- Preview flow with threading; do NOT keep extracted folder (clean up) ----------
    def preview_selected_animation(self):
        """
        Re-render (decode) the currently selected animation file using width/height/fps.
        Extracts frames in a background thread, builds in-memory sequence, then removes temp frames dir.
        """
        if not getattr(self, "selected_anim_file", None):
            QMessageBox.warning(self, "No file", "No animation file selected. Use 'Select MP4/GIF' first.")
            return
        sel = self.selected_anim_file
        w = int(self.width_spin.value())
        h = int(self.height_spin.value())
        fps = int(self.fps_spin.value())

        is_gif = sel.lower().endswith(".gif")
        ffmpeg_path_field = self.ffmpeg_edit.text().strip() or self.ffmpeg_resolved_path or ""
        if not is_gif and not ffmpeg_path_field and not shutil.which("ffmpeg"):
            QMessageBox.critical(self, "FFmpeg missing", "FFmpeg not configured in the FFmpeg field and not found in PATH. Set it before previewing videos.")
            return

        self.log(f"[INFO] Extracting frames for preview: {sel} @ {w}x{h} @{fps}fps")
        if is_gif:
            t = FuncThread(extract_gif_frames_sync, sel, w, h, fps)
        else:
            t = FuncThread(extract_video_frames_sync, sel, w, h, ffmpeg_path_field, fps)
        t._preview_src = sel
        t.done.connect(self._on_preview_extraction_done)
        self._start_thread(t)
        self.log("[INFO] Extraction thread started...")

    def _on_preview_extraction_done(self, result, error):
        if error:
            self.log(f"[ERROR] Extraction failed: {error}")
            QMessageBox.critical(self, "Extraction failed", str(error))
            return
        frames_dir = result
        self.log(f"[INFO] Frames extracted to: {frames_dir}")

        # Clean up any previously created frames dir to save space
        if self._last_created_frames_dir and os.path.isdir(self._last_created_frames_dir):
            try:
                shutil.rmtree(self._last_created_frames_dir)
            except Exception as e:
                self.log(f"[WARN] Failed deleting old temp frames: {e}")
        self._last_created_frames_dir = frames_dir

        # Build sequence from the flat frames (loads QPixmaps into RAM)
        # _on_loader_done will start playback when done
        self.build_sequence_from_flat_frames(frames_dir, which="created")

    def build_sequence_from_flat_frames(self, frames_dir: str, which: str = "created"):
        if not os.path.isdir(frames_dir):
            self.log(f"[ERROR] Frames folder missing: {frames_dir}")
            return
        try:
            fps = int(self.fps_spin.value()) if getattr(self, "fps_spin", None) else 30
        except Exception:
            fps = 30

        target_w = self.cur_label.width() if which == "current" else self.new_label.width()
        target_h = self.cur_label.height() if which == "current" else self.new_label.height()
        
        self.log(f"[INFO] Starting async frame loader for '{which}'...")
        self._launch_loader([frames_dir], target_w, target_h, fps, which)

    # ---------- create / push ----------
    def _detect_created_frames_dir(self) -> Optional[str]:
        # prefer existing extracted folder if present (though we normally clean up after loading)
        if self._last_created_frames_dir and os.path.isdir(self._last_created_frames_dir):
            return self._last_created_frames_dir
        # fallback: nothing (we rely on seq_created in memory)
        return None

    def create_bootanimation_zip(self):
        """
        Create zip from full-resolution frames directory.
        Never writes downscaled 220x488 preview QPixmaps from self.seq_created into part0.
        Immediately prompt user for save location.
        """
        # prompt for save location first
        fn, _ = QFileDialog.getSaveFileName(self, "Save created bootanimation.zip", self.created_zip_path or "", "ZIP files (*.zip)")
        if not fn:
            self.log("[INFO] Create cancelled by user (no save location).")
            return
        if not fn.lower().endswith(".zip"):
            fn += ".zip"
        self.created_zip_path = fn

        try:
            fps = int(self.fps_spin.value()) if hasattr(self, "fps_spin") else 30
        except Exception:
            fps = 30

        if not (self._last_created_frames_dir and os.path.exists(self._last_created_frames_dir)):
            if self.selected_video_path and os.path.exists(self.selected_video_path):
                self.log("[INFO] Regenerating full-resolution frames for export...")
                try:
                    self.generate_frames_from_video_sync(self.selected_video_path, fps)
                except Exception as e:
                    self.log(f"[ERROR] Failed to regenerate frames from video: {e}")
                    QMessageBox.critical(self, "Frame extraction error", f"Could not generate frames from video: {e}")
                    return

        frames_dir = self._detect_created_frames_dir()
        if not (frames_dir and os.path.isdir(frames_dir)):
            self.log("[ERROR] No frames directory available. Preview or select a video first.")
            QMessageBox.warning(self, "No frames", "No valid frames directory found to create bootanimation. Please select a video/animation first.")
            return

        tmp_build = tempfile.mkdtemp(prefix="qadb_build_")
        try:
            part0 = os.path.join(tmp_build, "part0")
            os.makedirs(part0, exist_ok=True)

            files = [f for f in os.listdir(frames_dir) if f.lower().endswith((".png", ".jpg", ".jpeg", ".webp", ".bmp"))]
            if not files:
                QMessageBox.warning(self, "No frames", "No image frames found in selected frames directory.")
                return
            files.sort(key=_frame_sort_key)
            for i, fname in enumerate(files):
                src = os.path.join(frames_dir, fname)
                dstname = f"{i:05d}.png"
                dst = os.path.join(part0, dstname)
                if not fname.lower().endswith(".png"):
                    try:
                        im = Image.open(src).convert("RGBA")
                        im.save(dst, format="PNG")
                    except Exception as e:
                        self.log(f"[WARN] Failed convert {src}: {e}")
                        shutil.copy2(src, dst)
                else:
                    shutil.copy2(src, dst)

            # write desc.txt based on current width/height/fps
            try:
                w = int(self.width_spin.value())
                h = int(self.height_spin.value())
                fps = int(self.fps_spin.value())
            except Exception:
                w, h, fps = 720, 240, 30
            desc = f"{w} {h} {fps}\n" + "p 1 0 part0\n"
            with open(os.path.join(tmp_build, "desc.txt"), "w", encoding="utf-8", newline='\n') as f:
                f.write(desc)

            # create zip
            zip_out = self.created_zip_path
            os.makedirs(os.path.dirname(zip_out) or ".", exist_ok=True)
            with zipfile.ZipFile(zip_out, "w", compression=zipfile.ZIP_STORED) as zf:
                for rootp, dirs, files2 in os.walk(tmp_build):
                    for fnm in files2:
                        full = os.path.join(rootp, fnm)
                        rel = os.path.relpath(full, tmp_build)
                        zf.write(full, rel.replace("\\", "/"))
            self.created_zip_path = zip_out
            self.log(f"[INFO] Created bootanimation.zip: {zip_out}")
            QMessageBox.information(self, "Created", f"Created: {zip_out}")
        except Exception as e:
            self.log(f"[ERROR] Create failed: {e}")
            QMessageBox.critical(self, "Create failed", str(e))
        finally:
            try:
                shutil.rmtree(tmp_build)
            except Exception:
                pass

    def push_zip_flow(self):
        """
        Replace older push_created_zip flow: show a dialog to either push the created zip or let user select one.
        """
        dlg = PushDialog(self, created_path=self.created_zip_path if self.created_zip_path and os.path.exists(self.created_zip_path) else None)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            self.log("[INFO] Push cancelled by user.")
            return
        chosen = dlg.path
        if not chosen or not os.path.exists(chosen):
            QMessageBox.warning(self, "No ZIP", "No ZIP selected or found.")
            return
        # run push in background with verbose logging returned
        t = FuncThread(self._push_zip_verbose_sync, chosen, self.remote_path, self.adb_cmd)
        t.done.connect(self._on_push_done)
        self._start_thread(t)
        self.log("[INFO] Push thread started...")

    def _on_push_done(self, result, error):
        if error:
            self.log(f"[ERROR] Push failed: {error}")
            QMessageBox.critical(self, "Push failed", str(error))
            return
        ok_msg = result
        # result is a multiline log string
        for ln in ok_msg.splitlines():
            self.log(ln)
        QMessageBox.information(self, "Push result", ok_msg)
        # optionally re-pull the device boot animation to refresh current preview/state
        try:
            self.pull_remote()
        except Exception:
            pass

    @staticmethod
    def _log_proc(logs: list, proc, label: str):
        """Append stdout/stderr from a subprocess result to the log list."""
        if proc.stdout:
            logs.append(f"[PUSH] {label} stdout: {proc.stdout.strip()}")
        if proc.stderr:
            logs.append(f"[PUSH] {label} stderr: {proc.stderr.strip()}")

    def _push_zip_verbose_sync(self, local_zip: str, remote_path: Optional[str], adb_cmd: Optional[str] = None) -> str:
        """
        Push the given local_zip to the device. Produce a verbose log describing each step.
        Returns a string (log).
        """
        logs = []
        if not os.path.exists(local_zip):
            raise RuntimeError("Local ZIP missing")
        if not remote_path:
            raise RuntimeError("Remote install path unknown. Run Find/Pull first.")

        tmp_remote = "/data/local/tmp/quickadb_push_bootanim.zip"
        target_dir = os.path.dirname(remote_path)
        q_tmp = shlex.quote(tmp_remote)
        q_remote = shlex.quote(remote_path)
        q_target = shlex.quote(target_dir)

        logs.append(f"[PUSH] Pushing {local_zip} -> {tmp_remote} via adb push")
        push = ADBClient.instance().push(local_zip, tmp_remote, use_serial=True, timeout=300.0)
        logs.append(f"[PUSH] adb push rc={push.returncode}")
        self._log_proc(logs, push, "push")
        if push.returncode != 0:
            raise RuntimeError("\n".join(logs + ["adb push failed"]))
        # attempt copy using root
        cp_cmd = f'su -c "cp {q_tmp} {q_remote} && chmod 0644 {q_remote}"'
        logs.append(f"[PUSH] Attempting root copy to {remote_path}")
        proc = ADBClient.instance().run_shell(cp_cmd, use_serial=True, timeout=60.0)
        logs.append(f"[PUSH] root copy rc={proc.returncode}")
        self._log_proc(logs, proc, "root copy")
        # if success
        if proc.returncode == 0:
            # cleanup tmp remote
            ADBClient.instance().run_shell(["su", "-c", f"rm -f {q_tmp}"], use_serial=True, timeout=10.0)
            logs.append(f"[PUSH] Installed to {remote_path} (root copy succeeded)")
            return "\n".join(logs)
        # try remount RW then copy
        logs.append("[PUSH] Root copy failed; attempting remount and retry")
        rem = ADBClient.instance().run_shell(["su", "-c", f"mount -o remount,rw {q_target} || mount -o remount,rw /system || mount -o remount,rw /system_root || true"], use_serial=True, timeout=20.0)
        logs.append(f"[PUSH] remount rc={rem.returncode}")
        self._log_proc(logs, rem, "remount")
        # retry copy
        proc2 = ADBClient.instance().run_shell(cp_cmd, use_serial=True, timeout=60.0)
        logs.append(f"[PUSH] retry root copy rc={proc2.returncode}")
        self._log_proc(logs, proc2, "retry")
        if proc2.returncode == 0:
            ADBClient.instance().run_shell(["su", "-c", f"rm -f {q_tmp}"], use_serial=True, timeout=10.0)
            logs.append(f"[PUSH] Installed to {remote_path} after remount")
            return "\n".join(logs)
        # final cleanup and error
        ADBClient.instance().run_shell(["su", "-c", f"rm -f {q_tmp}"], use_serial=True, timeout=10.0)
        logs.append("[PUSH] All methods failed to copy to target.")
        raise RuntimeError("\n".join(logs))

    # ---------- backup stock bootanimation (separate action) ----------
    def backup_stock_bootanimation(self):
        if not os.path.exists(PULLED_ZIP):
            QMessageBox.warning(self, "No pulled zip", "No pulled bootanimation.zip found to backup. Pull from device first.")
            return
        d = QFileDialog.getExistingDirectory(self, "Select backup directory (Cancel to skip)", self.backup_dir)
        if not d:
            self.log("[INFO] Backup cancelled by user.")
            return
        try:
            os.makedirs(d, exist_ok=True)
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            bak_name = os.path.join(d, f"bootanimation_backup_{ts}.zip")
            shutil.copy2(PULLED_ZIP, bak_name)
            self.backup_dir = d
            self.log(f"[INFO] Backed up pulled original to: {bak_name}")
            QMessageBox.information(self, "Backup", f"Backup created:\n{bak_name}")
        except Exception as e:
            self.log(f"[WARN] Failed backup copy: {e}")
            QMessageBox.critical(self, "Backup failed", str(e))

    # ---------- module creation flow ----------
    def create_flashable_module_flow(self):
        # Dialog to collect module metadata and save path
        if not getattr(self, "created_zip_path", None) or not os.path.exists(self.created_zip_path):
            QMessageBox.warning(self, "No created zip", "You need to create a bootanimation.zip first.")
            return
        if not getattr(self, "remote_path", None):
            QMessageBox.warning(self, "No remote path", "You must detect/pull the original bootanimation.zip first to know the install path.")
            return

        dlg = ModuleDialog(self)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            self.log("[INFO] Module creation cancelled by user.")
            return
        save_path = dlg.save_path
        meta = dlg.get_meta()
        # start background thread to build module zip
        t = FuncThread(create_module_sync, meta, save_path, self.created_zip_path, self.remote_path, "fl0w's QuickADB")
        t.done.connect(self._on_module_created)
        self._start_thread(t)
        self.log("[INFO] Module build thread started...")

    def _on_module_created(self, result, error):
        if error:
            self.log(f"[ERROR] Module creation failed: {error}")
            QMessageBox.critical(self, "Module failed", str(error))
            return
        self.log(f"[INFO] {result}")
        QMessageBox.information(self, "Module created", result)

    # ---------- playback tickers / controls ----------
    def _attrs(self, which: str):
        """Return the group of per-side attributes as a dict for the given side."""
        if which == "current":
            return dict(
                seq=self.seq_current,
                playing=self.playing_current,
                play_index="play_index_current",
                frame_ms=getattr(self, "frame_ms_current", 33),
                start_time="start_time_current",
                label=self.cur_label,
                meta=self.cur_meta,
                seek=self.cur_seek,
                play_btn=self.cur_play_btn,
                timer=self.timer_current,
            )
        return dict(
            seq=self.seq_created,
            playing=self.playing_created,
            play_index="play_index_created",
            frame_ms=getattr(self, "frame_ms_created", 33),
            start_time="start_time_created",
            label=self.new_label,
            meta=self.new_meta,
            seek=self.new_seek,
            play_btn=self.new_play_btn,
            timer=self.timer_created,
        )

    def _tick(self, which: str):
        a = self._attrs(which)
        if not a["seq"] or not a["playing"]:
            return
        total = len(a["seq"])
        if total == 0:
            return
        now_ms = int(time.time() * 1000)
        start = getattr(self, a["start_time"], None)
        if start is None:
            return
        elapsed = now_ms - start
        idx = int(elapsed / a["frame_ms"]) % total
        cur_idx = getattr(self, a["play_index"])
        if idx != cur_idx:
            setattr(self, a["play_index"], idx)
            self._update_preview(which)

    def _tick_current(self):
        self._tick("current")

    def _tick_created(self):
        self._tick("created")

    def _start(self, which: str):
        a = self._attrs(which)
        if not a["seq"]:
            self.log(f"No {which} sequence to play.")
            return
        idx = getattr(self, a["play_index"])
        if which == "current":
            self.playing_current = True
        else:
            self.playing_created = True
        a["play_btn"].setText("⏸")
        setattr(self, a["start_time"], int(time.time() * 1000) - (idx * a["frame_ms"]))
        a["timer"].start(int(a["frame_ms"] / 2))
        self._update_preview(which)

    def start_current(self):
        self._start("current")

    def start_created(self):
        self._start("created")

    def _stop(self, which: str):
        a = self._attrs(which)
        if which == "current":
            self.playing_current = False
        else:
            self.playing_created = False
        a["play_btn"].setText("▶")
        a["timer"].stop()

    def stop_current(self):
        self._stop("current")

    def stop_created(self):
        self._stop("created")

    def _on_seek_moved(self, which, value):
        a = self._attrs(which)
        if a["seq"]:
            setattr(self, a["play_index"], value)
            self._update_preview(which)
            if a["playing"]:
                idx = getattr(self, a["play_index"])
                setattr(self, a["start_time"], int(time.time() * 1000) - (idx * a["frame_ms"]))

    def _update_preview(self, which: str):
        a = self._attrs(which)
        seq = a["seq"]
        if not seq:
            return
        idx = getattr(self, a["play_index"])
        pix, ms, fname = seq[idx]
        a["label"].setPixmap(pix)
        total_s = (len(seq) * ms) / 1000
        curr_s = (idx * ms) / 1000
        a["meta"].setText(f"{fname} | {curr_s:.1f}s / {total_s:.1f}s | {idx + 1}/{len(seq)}")
        a["seek"].blockSignals(True)
        a["seek"].setValue(idx)
        a["seek"].blockSignals(False)

    def toggle_current(self):
        self._toggle("current")

    def toggle_created(self):
        self._toggle("created")

    def _toggle(self, which: str):
        a = self._attrs(which)
        if a["playing"]:
            a["timer"].stop()
            if which == "current":
                self.playing_current = False
            else:
                self.playing_created = False
            a["play_btn"].setText("▶")
        else:
            self._start(which)

    def open_work_directory(self):
        frames_dir = self._detect_created_frames_dir()
        if frames_dir and os.path.exists(frames_dir):
            target = frames_dir
        elif WORK_DIR and os.path.exists(WORK_DIR):
            target = WORK_DIR
        else:
            self.log("[WARN] Work directory not found.")
            return
            
        QDesktopServices.openUrl(QUrl.fromLocalFile(os.path.abspath(target)))
        self.log(f"[INFO] Opening directory: {target}")

    def reload_frames_from_workdir(self):
        frames_dir = self._detect_created_frames_dir()
        if not frames_dir or not os.path.isdir(frames_dir):
            QMessageBox.warning(self, "No frames", "No extracted frames directory found to reload from.")
            return
        self.log(f"[INFO] Reloading frames from: {frames_dir}")
        self.build_sequence_from_flat_frames(frames_dir, which="created")

    def clear_all_frames(self):
        reply = QMessageBox.question(self, "Clear All?", "This will delete all extracted frames in the temporary work directory and clear previews.\n\nProceed?",
                                   QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            self.seq_current = []
            self.seq_created = []
            self.cur_label.clear(); self.cur_label.setText("Cleared")
            self.new_label.clear(); self.new_label.setText("Cleared")
            self.playing_current = False; self.playing_created = False
            self.cur_play_btn.setText("▶"); self.new_play_btn.setText("▶")
            self.log("[INFO] Sequences cleared.")
            # wipe EXTRACT_DIR if it exists
            if EXTRACT_DIR and os.path.exists(EXTRACT_DIR):
                try:
                    shutil.rmtree(EXTRACT_DIR)
                    os.makedirs(EXTRACT_DIR, exist_ok=True)
                    self.log("[INFO] Temp extract folder wiped.")
                except Exception as e:
                    self.log(f"[WARN] Failed wiping workdir: {e}")

    # ---------- misc UI helpers ----------
    def choose_created_zip(self):
        fn, _ = QFileDialog.getSaveFileName(self, "Choose created bootanimation.zip", self.created_zip_path, "ZIP files (*.zip)")
        if not fn:
            return
        if not fn.lower().endswith(".zip"):
            fn += ".zip"
        self.created_zip_path = fn
        self.log(f"Created zip set to: {fn}")

    def closeEvent(self, ev):
        try:
            self.timer_current.stop(); self.timer_created.stop()
        except Exception:
            pass
        # try to quit running threads
        for t in list(self._threads):
            try:
                if t.isRunning():
                    t.quit()
                    t.wait(2000)
            except Exception:
                pass
        # cleanup temporary work dir
        try:
            cleanup_work_dirs()
            self.log("[INFO] Cleaned temporary work directory.")
        except Exception:
            pass
        super().closeEvent(ev)


BootAnimCreator = BootAnimWidget

if __name__ == "__main__":
    app = QApplication(sys.argv)
    w = run_bootanim_creator()
    sys.exit(app.exec())
