#!/usr/bin/env python3

"""
build.py - Build script for QuickADB.
Downloads external dependancies and uses PyInstaller to compile the tool into a single binary.
Linux builds are also wrapped into AppImage files.

"""

import os
import sys
import platform
import urllib.request
import zipfile
import tarfile
import gzip
import shutil
import subprocess

# URLs for dependencies
PLATFORM_TOOLS_URLS = {
    "Windows": "https://dl.google.com/android/repository/platform-tools-latest-windows.zip",
    "Linux": "https://dl.google.com/android/repository/platform-tools-latest-linux.zip",
    "Darwin": "https://dl.google.com/android/repository/platform-tools-latest-darwin.zip"
}

# QuickADB uses payload-dumper-go by ssut. Since it doesn't have ARM64 builds, we cannot incorporate the dumper on WinARM versions.
PAYLOAD_DUMPER_URLS = {
    ("Windows", "x86_64"): "https://github.com/ssut/payload-dumper-go/releases/download/1.3.0/payload-dumper-go_1.3.0_windows_amd64.tar.gz",
    ("Linux", "x86_64"): "https://github.com/ssut/payload-dumper-go/releases/download/1.3.0/payload-dumper-go_1.3.0_linux_amd64.tar.gz",
    ("Linux", "arm64"): "https://github.com/ssut/payload-dumper-go/releases/download/1.3.0/payload-dumper-go_1.3.0_linux_arm64.tar.gz",
    ("Darwin", "x86_64"): "https://github.com/ssut/payload-dumper-go/releases/download/1.3.0/payload-dumper-go_1.3.0_darwin_amd64.tar.gz",
    ("Darwin", "arm64"): "https://github.com/ssut/payload-dumper-go/releases/download/1.3.0/payload-dumper-go_1.3.0_darwin_arm64.tar.gz"
}

APPIMAGE_TOOL_URLS = {
    "x86_64": "https://github.com/AppImage/appimagetool/releases/download/continuous/appimagetool-x86_64.AppImage",
    "arm64": "https://github.com/AppImage/appimagetool/releases/download/continuous/appimagetool-aarch64.AppImage"
}

UNSUPER_URL = "https://raw.githubusercontent.com/codefl0w/unsuper/refs/heads/main/unsuper.py"

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
UTIL_DIR = os.path.join(ROOT_DIR, "util")
DIST_DIR = os.path.join(ROOT_DIR, "dist")
try:
    from util.resource import APP_VERSION
except ImportError:
    if ROOT_DIR not in sys.path:
        sys.path.insert(0, ROOT_DIR)
    try:
        from util.resource import APP_VERSION
    except ImportError:
        APP_VERSION = "V5.3.6"

def get_arch():
    # Detect machine architecture and normalize to x86_64 or arm64
    machine = platform.machine().lower()
    if machine in ("arm64", "aarch64", "armv8l"):
        return "arm64"
    return "x86_64"

def download_file(url, dest):
    print(f"Downloading {url}...")
    try:
        urllib.request.urlretrieve(url, dest)
    except Exception as e:
        print(f"Failed to download {url}: {e}")


def extract_archive(archive_path, dest_dir):
    """
    Safely extracts a zip or tar archive into dest_dir, validating each member's
    target path using os.path.realpath to prevent directory traversal outside dest_dir.
    """
    if not os.path.exists(archive_path):
        raise FileNotFoundError(f"Archive not found: {archive_path}")

    print(f"Extracting {archive_path} to {dest_dir}...")
    os.makedirs(dest_dir, exist_ok=True)
    dest_real = os.path.realpath(dest_dir)

    if zipfile.is_zipfile(archive_path):
        with zipfile.ZipFile(archive_path, 'r') as zip_ref:
            for member in zip_ref.namelist():
                target_path = os.path.realpath(os.path.join(dest_dir, member))
                try:
                    is_safe = (os.path.commonpath([os.path.normcase(dest_real), os.path.normcase(target_path)]) == os.path.normcase(dest_real))
                except ValueError:
                    is_safe = False
                if not is_safe:
                    raise ValueError(f"Path traversal detected in zip archive member: {member}")
            zip_ref.extractall(dest_dir)
    else:
        # tarfile handles both .tar and compressed .tar (.tar.gz, etc.) via 'r:*'
        tar_path = archive_path
        cleanup_tar = False
        if archive_path.endswith(".tar.gz"):
            tar_path = archive_path.replace(".tar.gz", ".tar")
            with gzip.open(archive_path, 'rb') as f_in:
                with open(tar_path, 'wb') as f_out:
                    shutil.copyfileobj(f_in, f_out)
            cleanup_tar = True

        try:
            with tarfile.open(tar_path, 'r:*') as tar_ref:
                for member in tar_ref.getmembers():
                    target_path = os.path.realpath(os.path.join(dest_dir, member.name))
                    try:
                        is_safe = (os.path.commonpath([os.path.normcase(dest_real), os.path.normcase(target_path)]) == os.path.normcase(dest_real))
                    except ValueError:
                        is_safe = False
                    if not is_safe:
                        raise ValueError(f"Path traversal detected in tar archive member: {member.name}")
                    if member.issym() or member.islnk():
                        link_target = os.path.realpath(os.path.join(dest_dir, os.path.dirname(member.name), member.linkname))
                        try:
                            is_link_safe = (os.path.commonpath([os.path.normcase(dest_real), os.path.normcase(link_target)]) == os.path.normcase(dest_real))
                        except ValueError:
                            is_link_safe = False
                        if not is_link_safe:
                            raise ValueError(f"Path traversal detected in tar archive member link: {member.name} -> {member.linkname}")
                if hasattr(tarfile, 'data_filter'):
                    tar_ref.extractall(dest_dir, filter='data')
                else:
                    tar_ref.extractall(dest_dir)
        finally:
            if cleanup_tar and os.path.exists(tar_path):
                os.remove(tar_path)

def extract_zip(src, dest_dir):
    extract_archive(src, dest_dir)

def extract_targz_payload_dumper(src, dest_dir):
    extract_archive(src, dest_dir)

def create_linux_appimage(arch):
    print(f"Creating Linux AppImage for {arch}...")
    appdir = os.path.join(ROOT_DIR, "QuickADB.AppDir")
    if os.path.exists(appdir):
        shutil.rmtree(appdir)

    os.makedirs(os.path.join(appdir, "usr/bin"), exist_ok=True)

    # 1. Copy PyInstaller output to AppDir
    exe_src = os.path.join(DIST_DIR, "QuickADB")
    exe_dest = os.path.join(appdir, "usr/bin/QuickADB")
    if not os.path.exists(exe_src):
        print(f"Error: Bundled executable not found at {exe_src}")
        return
    shutil.copy2(exe_src, exe_dest)
    os.chmod(exe_dest, 0o755)

    # 2. Create Desktop file
    desktop_content = """[Desktop Entry]
Type=Application
Name=QuickADB
Exec=QuickADB
Icon=QuickADB
Categories=Utility;System;
Terminal=false
"""
    with open(os.path.join(appdir, "QuickADB.desktop"), "w") as f:
        f.write(desktop_content)

    # 3. Handle Icon (use logo.svg as QuickADB.svg)
    icon_src = os.path.join(ROOT_DIR, "res/toolicon.png")
    if os.path.exists(icon_src):
        shutil.copy2(icon_src, os.path.join(appdir, "QuickADB.png"))

    # 4. Create AppRun script
    apprun_content = """#!/bin/sh
SELF=$(readlink -f "$0")
HERE=$(dirname "$SELF")
export PATH="${HERE}/usr/bin:${PATH}"
exec QuickADB "$@"
"""
    apprun_path = os.path.join(appdir, "AppRun")
    with open(apprun_path, "w") as f:
        f.write(apprun_content)
    os.chmod(apprun_path, 0o755)

    # 5. Download appimagetool
    tool_path = os.path.join(ROOT_DIR, "appimagetool")
    if not os.path.exists(tool_path):
        appimage_url = APPIMAGE_TOOL_URLS.get(arch, APPIMAGE_TOOL_URLS["x86_64"])
        download_file(appimage_url, tool_path)
        os.chmod(tool_path, 0o755)

    # 6. Build AppImage
    env = os.environ.copy()
    env["ARCH"] = "aarch64" if arch == "arm64" else "x86_64"

    cmd = [tool_path, "--appimage-extract-and-run", "--comp", "zstd", appdir]
    try:
        subprocess.run(cmd, check=True, env=env, cwd=ROOT_DIR)
        output_name = f"QuickADB_{APP_VERSION}_Linux_{arch}.AppImage"
        # Find generated AppImage file and rename
        for f in os.listdir(ROOT_DIR):
            if f.endswith(".AppImage") and f != "appimagetool":
                target_path = os.path.join(ROOT_DIR, output_name)
                if os.path.exists(target_path):
                    os.remove(target_path)
                os.rename(os.path.join(ROOT_DIR, f), target_path)
                print(f"AppImage created successfully as {output_name}")
                break
    except subprocess.CalledProcessError as e:
        print(f"AppImage creation failed with exit code {e.returncode}")

def cleanup_processes():
    # Terminate known background processes to avoid file locking on Windows
    if platform.system() != "Windows":
        return

    processes = ["adb.exe", "fastboot.exe", "payload-dumper-go.exe", "QuickADB.exe"]
    print("Cleaning up background processes...")
    for proc in processes:
        try:
            subprocess.run(["taskkill", "/F", "/IM", proc, "/T"],
                           capture_output=True, check=False)
        except Exception:
            pass

def main():
    os_name = platform.system()
    arch = get_arch()

    if os_name not in PLATFORM_TOOLS_URLS:
        print(f"Unsupported OS: {os_name}")
        sys.exit(1)

    print(f"Building QuickADB {APP_VERSION} for {os_name} ({arch})...")

    # Pre-build cleanup
    cleanup_processes()

    # Clean old build/dist and dependencies
    print("Cleaning environment...")
    dirs_to_clean = ["build", "dist", "QuickADB.AppDir", "temp_pd"]  # keep platform-tools: source runs use it
    for d in dirs_to_clean:
        full_d = os.path.join(ROOT_DIR, d)
        if os.path.exists(full_d):
            try:
                shutil.rmtree(full_d)
            except Exception as e:
                print(f"Warning: Could not remove {d}: {e}")

    # Clean specific binaries in util
    pd_binary = "payload-dumper-go"
    if os_name == "Windows":
        pd_binary += ".exe"
    pd_dest = os.path.join(UTIL_DIR, pd_binary)
    if os.path.exists(pd_dest):
        try:
            os.remove(pd_dest)
        except Exception as e:
            print(f"Warning: Could not remove {pd_binary}: {e}")

    # Clean unsuper.py if it exists
    unsuper_dest = os.path.join(UTIL_DIR, "unsuper.py")
    if os.path.exists(unsuper_dest):
        try:
            os.remove(unsuper_dest)
        except Exception as e:
            print(f"Warning: Could not remove unsuper.py: {e}")

    # Clean appimagetool if it exists
    tool_path = os.path.join(ROOT_DIR, "appimagetool")
    if os.path.exists(tool_path):
        try:
            os.remove(tool_path)
        except Exception as e:
            print(f"Warning: Could not remove appimagetool: {e}")

    # 1. platform-tools is no longer bundled into the executable. At runtime QuickADB uses
    #    adb from the system PATH or from its own folder, and offers to download it if missing.

    # 2. Download and Extract Payload Dumper Go (skipped on Windows ARM64 as upstream binaries are unavailable)
    if os_name == "Windows" and arch == "arm64":
        print("[WARNING] payload-dumper-go is not available upstream for Windows ARM64. Skipping download...")
    else:
        pd_url = PAYLOAD_DUMPER_URLS.get((os_name, arch), PAYLOAD_DUMPER_URLS.get((os_name, "x86_64")))
        pd_targz = os.path.join(ROOT_DIR, "payload-dumper-go.tar.gz")
        download_file(pd_url, pd_targz)

        temp_pd_dir = os.path.join(ROOT_DIR, "temp_pd")
        os.makedirs(temp_pd_dir, exist_ok=True)
        extract_targz_payload_dumper(pd_targz, temp_pd_dir)

        binary_name = "payload-dumper-go"
        if os_name == "Windows":
            binary_name += ".exe"

        src_binary = os.path.join(temp_pd_dir, binary_name)
        if not os.path.exists(src_binary):
            for root, dirs, files in os.walk(temp_pd_dir):
                for f in files:
                    if f.startswith("payload-dumper-go"):
                        src_binary = os.path.join(root, f)
                        break

        if os.path.exists(src_binary):
            dest_binary = os.path.join(UTIL_DIR, binary_name)
            os.makedirs(UTIL_DIR, exist_ok=True)
            shutil.move(src_binary, dest_binary)
            if os_name != "Windows":
                os.chmod(dest_binary, 0o755)
            print(f"Moved {binary_name} to {UTIL_DIR}")
        else:
            print(f"Error: Could not find {binary_name} in the archive.")

        shutil.rmtree(temp_pd_dir)
        if os.path.exists(pd_targz):
            os.remove(pd_targz)

    # 3. Download unsuper
    print("Downloading unsuper.py...")
    unsuper_dest = os.path.join(UTIL_DIR, "unsuper.py")
    os.makedirs(UTIL_DIR, exist_ok=True)
    download_file(UNSUPER_URL, unsuper_dest)
    if not os.path.exists(unsuper_dest) or os.path.getsize(unsuper_dest) == 0:
        print("Error: Could not download unsuper.py")
        sys.exit(1)

    # 5. Run PyInstaller
    print("Starting PyInstaller build...")
    spec_path = os.path.join(ROOT_DIR, "QuickADB.spec")
    build_cmd = ["pyinstaller", "--noconfirm", spec_path]

    try:
        subprocess.run(build_cmd, check=True, cwd=ROOT_DIR)
        print("PyInstaller build completed successfully!")
    except subprocess.CalledProcessError as e:
        print(f"PyInstaller build failed with exit code {e.returncode}")
        sys.exit(e.returncode)

    # 6. Output naming & Linux AppImage Step
    if os_name == "Linux":
        create_linux_appimage(arch)
    else:
        ext = ".exe" if os_name == "Windows" else ""
        original_bin = os.path.join(DIST_DIR, f"QuickADB{ext}")
        final_bin_name = f"QuickADB_{APP_VERSION}_{os_name}_{arch}{ext}"
        final_bin = os.path.join(DIST_DIR, final_bin_name)
        if os.path.exists(original_bin):
            if os.path.exists(final_bin):
                os.remove(final_bin)
            os.rename(original_bin, final_bin)
            print(f"Final output built at {final_bin}")

if __name__ == "__main__":
    main()
